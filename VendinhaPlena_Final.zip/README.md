# Vendinha Plena - Backend

Este projeto é um sistema de controle de dívidas ("penduras") para uma pequena venda, permitindo o gerenciamento de clientes e suas respectivas dívidas.

## Tecnologias Utilizadas

- **.NET 8** (C#)
- **ASP.NET Core Web API**
- **Entity Framework Core**
- **SQLite** (Padrão para desenvolvimento local)
- **PostgreSQL** (Suportado)
- **Swagger/OpenAPI** para documentação dos endpoints

## Requisitos do Sistema

- CRUD completo de clientes (Nome, CPF, Data de Nascimento, Email).
- Cálculo automático de idade.
- Validação de CPF (Algoritmo oficial).
- Regra de negócio: Um cliente só pode ter uma dívida em aberto por vez.
- Listagem de clientes com ordenação por maior dívida e paginação (10 em 10).
- Busca de clientes por nome.

## Como Executar

### Pré-requisitos
- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) instalado.

### Passos para execução
1. Clone o repositório.
2. Navegue até a pasta do projeto API:
   ```bash
   cd VendinhaPlena.API
   ```
3. Execute a aplicação:
   ```bash
   dotnet run
   ```
4. O Swagger estará disponível em: `http://localhost:5241/swagger` (verifique a porta no console).

## Configuração de Banco de Dados

A aplicação está configurada para usar **SQLite** por padrão para facilitar o teste imediato.

### Alterando para PostgreSQL
No arquivo `appsettings.json`, altere:
- `"DatabaseProvider": "PostgreSQL"`
- Ajuste a string de conexão em `"PostgreSqlConnection"`.

### Script SQL
O script para criação manual do banco de dados PostgreSQL encontra-se em:
`VendinhaPlena.API/Data/schema.sql`

## Estrutura do Projeto
- **Controllers**: Endpoints da API.
- **Services**: Camada de lógica de negócio (atendendo ao requisito de melhor organização).
- **DTOs**: Objetos de transferência de dados para entrada e saída.
- **Models**: Entidades do banco de dados.
- **Data**: Contexto do Entity Framework e scripts SQL.
- **Utils**: Utilitários como validador de CPF.

## Endpoints Principais

### Clientes
- `GET /api/Clientes`: Lista clientes (com paginação, busca e ordenação).
- `POST /api/Clientes`: Cadastra novo cliente.
- `GET /api/Clientes/{id}`: Detalhes do cliente.
- `PUT /api/Clientes/{id}`: Atualiza cliente.
- `DELETE /api/Clientes/{id}`: Remove cliente.

### Dívidas
- `POST /api/Dividas`: Cadastra nova dívida (valida se já existe uma aberta).
- `GET /api/Dividas/cliente/{clienteId}`: Lista dívidas de um cliente.
- `PATCH /api/Dividas/{id}/pagar`: Marca uma dívida como paga.
